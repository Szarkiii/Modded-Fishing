package com.example.moddedfishing;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;

/**
 * Auto-clicker for fishing systems where:
 * - A RANDOM COLOR appears (doesn't matter what color)
 * - A RANDOM NUMBER (2-9) is displayed
 * - You must click the hotbar slot MATCHING THE NUMBER
 * 
 * This addon detects the NUMBER and clicks the correct slot automatically
 */
public class ModdedFishingAutoclicker {
    private static final Minecraft minecraft = Minecraft.getInstance();
    
    private static boolean isAutoFishing = false;
    private static int numberDetectionCounter = 0;
    private static int clickDelayCounter = 0;
    private static int lastDetectedNumber = -1;
    private static boolean justClicked = false;
    
    public static boolean isAutoFishing() {
        return isAutoFishing;
    }
    
    public static void toggleAutoFishing() {
        isAutoFishing = !isAutoFishing;
        if (!isAutoFishing) {
            reset();
        }
    }
    
    public static void setAutoFishing(boolean state) {
        isAutoFishing = state;
        if (!isAutoFishing) {
            reset();
        }
    }
    
    private static void reset() {
        numberDetectionCounter = 0;
        clickDelayCounter = 0;
        lastDetectedNumber = -1;
        justClicked = false;
        FishingColorDetector.reset();
    }
    
    /**
     * Main tick method - called every game tick
     * Detects the number and clicks the corresponding hotbar slot
     */
    public static void onClientTick(Minecraft mc) {
        if (!isAutoFishing) {
            return;
        }
        
        Player player = mc.player;
        if (player == null) {
            return;
        }
        
        // Increment counters
        numberDetectionCounter++;
        if (clickDelayCounter > 0) {
            clickDelayCounter--;
        }
        
        // Periodically detect the number
        int detectionDelay = ModdedFishingConfig.CONFIG.colorDetectionDelay.get();
        if (numberDetectionCounter >= detectionDelay) {
            numberDetectionCounter = 0;
            
            // Detect the current number (2-9)
            int detectedNumber = FishingColorDetector.detectShownNumber();
            
            if (detectedNumber >= 2 && detectedNumber <= 9) {
                // Number detected!
                if (detectedNumber != lastDetectedNumber || !justClicked) {
                    lastDetectedNumber = detectedNumber;
                    clickDelayCounter = ModdedFishingConfig.CONFIG.clickDelay.get();
                    
                    if (ModdedFishingConfig.CONFIG.enableDebug.get()) {
                        player.displayClientMessage(
                                net.minecraft.network.chat.Component.literal(
                                        "§6[AutoFish] Detected number: §f" + detectedNumber),
                                true
                        );
                    }
                }
            }
        }
        
        // Handle delayed click
        if (clickDelayCounter == 0 && lastDetectedNumber >= 2 && lastDetectedNumber <= 9 && !justClicked) {
            performSlotClick(lastDetectedNumber);
            justClicked = true;
        } else if (clickDelayCounter == 0) {
            justClicked = false;
        }
    }
    
    /**
     * Performs the actual hotbar slot click
     * 
     * The number shown is 2-9, and hotbar slots are 1-9
     * So if number is 5, click hotbar slot 5
     * Number directly corresponds to slot index (plus 1 for hotbar conversion)
     */
    private static void performSlotClick(int numberShown) {
        Player player = minecraft.player;
        if (player == null) {
            return;
        }
        
        // Validate number (2-9)
        if (numberShown < 2 || numberShown > 9) {
            return;
        }
        
        try {
            // Click the hotbar slot that matches the number
            // Hotbar slots are 0-8 for positions 1-9
            // But number is 2-9, so we directly use numberShown as the slot
            // Actually, hotbar slots work like this:
            // Slot 1 = key "1" (hotbar index 0)
            // Slot 2 = key "2" (hotbar index 1)
            // ...
            // Slot 9 = key "9" (hotbar index 8)
            
            // The number shown (2-9) corresponds directly to the slot to click
            int slotToSelect = numberShown - 1; // Convert to 0-8 range
            
            // Select the hotbar slot
            player.getInventory().selected = slotToSelect;
            
            if (ModdedFishingConfig.CONFIG.enableDebug.get()) {
                player.displayClientMessage(
                        net.minecraft.network.chat.Component.literal(
                                "§a[AutoFish] Clicked slot " + numberShown),
                        true
                );
            }
            
            if (ModdedFishingConfig.CONFIG.playSound.get()) {
                playClickSound();
            }
        } catch (Exception e) {
            // Fail silently
        }
    }
    
    /**
     * Plays a click sound (optional)
     */
    private static void playClickSound() {
        try {
            if (minecraft.player != null) {
                // Play a click sound
                minecraft.player.playNotifySound(
                        net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.getLocation(),
                        net.minecraft.sounds.SoundSource.PLAYERS,
                        0.5f,
                        1.0f
                );
            }
        } catch (Exception e) {
            // Fail silently
        }
    }
    
    /**
     * Gets current auto-fishing status string for debug
     */
    public static String getStatusString() {
        return "AutoFish: " + (isAutoFishing ? "§aON" : "§cOFF") + 
               " | Last Number: " + (lastDetectedNumber >= 2 ? lastDetectedNumber : "§cNone") +
               " | Detection: " + numberDetectionCounter;
    }
}
