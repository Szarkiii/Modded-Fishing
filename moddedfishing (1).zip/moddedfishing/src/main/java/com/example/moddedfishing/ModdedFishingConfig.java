package com.example.moddedfishing;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.common.Mod;
import org.apache.commons.lang3.tuple.Pair;

@Mod.EventBusSubscriber(modid = ModdedAutoFishing.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModdedFishingConfig {
    public static final ForgeConfigSpec SPEC;
    public static final Config CONFIG;

    static {
        Pair<Config, ForgeConfigSpec> configPair = new ForgeConfigSpec.Builder()
                .configure(Config::new);
        SPEC = configPair.getRight();
        CONFIG = configPair.getLeft();
    }

    public static class Config {
        public final ForgeConfigSpec.IntValue colorDetectionDelay;
        public final ForgeConfigSpec.IntValue clickDelay;
        public final ForgeConfigSpec.BooleanValue enableDebug;
        public final ForgeConfigSpec.DoubleValue pixelTolerance;
        public final ForgeConfigSpec.BooleanValue playSound;

        public Config(ForgeConfigSpec.Builder builder) {
            builder.comment("Modded Auto Fishing Configuration")
                    .push("fishing");

            colorDetectionDelay = builder
                    .comment("Ticks between color detection attempts (20 ticks = 1 second)")
                    .defineInRange("color_detection_delay", 1, 1, 20);

            clickDelay = builder
                    .comment("Ticks delay after detecting color before clicking")
                    .defineInRange("click_delay", 2, 0, 20);

            enableDebug = builder
                    .comment("Enable debug messages in chat (logs detected colors)")
                    .define("enable_debug", false);

            pixelTolerance = builder
                    .comment("Pixel tolerance for color detection (0.0-1.0, higher = more lenient)")
                    .defineInRange("pixel_tolerance", 0.15, 0.0, 1.0);

            playSound = builder
                    .comment("Play click sound when slot is clicked")
                    .define("play_click_sound", false);

            builder.pop();
        }
    }
}
