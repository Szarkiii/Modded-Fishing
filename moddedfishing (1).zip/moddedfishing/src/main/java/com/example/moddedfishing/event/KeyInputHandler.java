package com.example.moddedfishing.event;

import com.example.moddedfishing.ModdedAutoFishing;
import com.example.moddedfishing.ModdedFishingAutoclicker;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = ModdedAutoFishing.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class KeyInputHandler {
    private static final int TOGGLE_KEY = GLFW.GLFW_KEY_F;
    
    @SubscribeEvent
    public static void onKeyInput(InputEvent.Key event) {
        // Toggle auto-fishing with F key
        if (event.getKey() == TOGGLE_KEY && event.getAction() == GLFW.GLFW_PRESS) {
            ModdedFishingAutoclicker.toggleAutoFishing();
            
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.player != null) {
                boolean state = ModdedFishingAutoclicker.isAutoFishing();
                String message = state ? 
                        "§a✓ Color Auto-Fishing ENABLED" : 
                        "§cColor Auto-Fishing DISABLED";
                minecraft.player.displayClientMessage(
                        net.minecraft.network.chat.Component.literal(message), 
                        false
                );
            }
        }
    }
}
