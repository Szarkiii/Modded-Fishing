package com.example.moddedfishing.event;

import com.example.moddedfishing.ModdedAutoFishing;
import com.example.moddedfishing.ModdedFishingAutoclicker;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.client.Minecraft;

@Mod.EventBusSubscriber(modid = ModdedAutoFishing.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientTickHandler {
    
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            Minecraft minecraft = Minecraft.getInstance();
            
            // Only run if player exists
            if (minecraft.player != null && !minecraft.isPaused()) {
                ModdedFishingAutoclicker.onClientTick(minecraft);
            }
        }
    }
}
