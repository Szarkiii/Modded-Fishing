package com.example.moddedfishing;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

import java.nio.IntBuffer;

/**
 * Detects the NUMBER (2-9) displayed during fishing minigame
 * The COLOR is random and doesn't matter - only the NUMBER matters!
 * 
 * This system detects the displayed digit by analyzing brightness patterns on screen
 */
public class FishingColorDetector {
    private static final Minecraft minecraft = Minecraft.getInstance();
    private static int lastDetectedNumber = -1;
    private static int ticksSinceLastDetection = 0;
    private static int consecutiveMatches = 0;
    private static final int MATCH_THRESHOLD = 3; // Require multiple detections to confirm
    
    /**
     * Main detection method - finds the NUMBER (2-9) shown on screen
     * Colors are random, so we detect by:
     * 1. Finding bright text/numbers on screen
     * 2. Analyzing digit shape patterns
     * 3. Confirming with multiple consecutive detections
     */
    public static int detectShownNumber() {
        try {
            int detectedNumber = detectNumberFromScreen();
            
            if (detectedNumber >= 2 && detectedNumber <= 9) {
                if (detectedNumber == lastDetectedNumber) {
                    consecutiveMatches++;
                } else {
                    consecutiveMatches = 1;
                    lastDetectedNumber = detectedNumber;
                }
                
                // Only confirm after multiple consistent detections
                if (consecutiveMatches >= MATCH_THRESHOLD) {
                    ticksSinceLastDetection = 0;
                    return lastDetectedNumber;
                }
            } else {
                consecutiveMatches = 0;
            }
        } catch (Exception e) {
            consecutiveMatches = 0;
        }
        
        ticksSinceLastDetection++;
        return lastDetectedNumber; // Return last confirmed number
    }
    
    /**
     * Analyzes screen pixels to find the number
     * Looks for bright/text pixels that form digit shapes
     */
    private static int detectNumberFromScreen() {
        try {
            int width = minecraft.getWindow().getWidth();
            int height = minecraft.getWindow().getHeight();
            
            IntBuffer pixelBuffer = IntBuffer.allocate(width * height);
            GL11.glReadPixels(0, 0, width, height, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, pixelBuffer);
            
            return analyzeNumberPatterns(pixelBuffer, width, height);
        } catch (Exception e) {
            return -1;
        }
    }
    
    /**
     * Analyzes pixel patterns to detect which digit (2-9) is shown
     * Uses brightness and distribution analysis
     */
    private static int analyzeNumberPatterns(IntBuffer pixels, int width, int height) {
        // Focus on center area of screen where number would be displayed
        int centerX = width / 2;
        int centerY = height / 2;
        int searchRadius = Math.min(width, height) / 8; // Search center area
        
        // Count bright pixels (text) and their positions
        int totalBrightPixels = 0;
        int[] regionCounts = new int[9]; // 9 regions for pattern matching
        double[] regionX = new double[9]; // Center of mass for each region
        double[] regionY = new double[9];
        
        // Analyze pixels in the search area
        for (int y = centerY - searchRadius; y <= centerY + searchRadius; y++) {
            for (int x = centerX - searchRadius; x <= centerX + searchRadius; x++) {
                if (y >= 0 && y < height && x >= 0 && x < width) {
                    int pixelIndex = y * width + x;
                    if (pixelIndex >= 0 && pixelIndex < pixels.capacity()) {
                        int argb = pixels.get(pixelIndex);
                        
                        int r = (argb >> 16) & 0xFF;
                        int g = (argb >> 8) & 0xFF;
                        int b = argb & 0xFF;
                        
                        int brightness = (r + g + b) / 3;
                        
                        // Text is typically bright, background is dark
                        if (brightness > 120) { // Threshold for bright pixels
                            totalBrightPixels++;
                            
                            // Categorize into 3x3 grid regions
                            int regionX_idx = (x - (centerX - searchRadius)) * 3 / (2 * searchRadius);
                            int regionY_idx = (y - (centerY - searchRadius)) * 3 / (2 * searchRadius);
                            
                            regionX_idx = Math.max(0, Math.min(2, regionX_idx));
                            regionY_idx = Math.max(0, Math.min(2, regionY_idx));
                            
                            int regionIndex = regionY_idx * 3 + regionX_idx;
                            regionCounts[regionIndex]++;
                        }
                    }
                }
            }
        }
        
        // Need minimum bright pixels to detect a number
        if (totalBrightPixels < 100) {
            return -1;
        }
        
        // Analyze region distribution to identify digit
        return matchRegionPatternToNumber(regionCounts);
    }
    
    /**
     * Matches pixel distribution patterns to digit shapes (2-9)
     * 
     * Number shapes have distinct patterns:
     * 2: Top-left, top-right, middle, bottom-left, bottom-right
     * 3: Top-left, top-right, middle, bottom-right (similar to 2)
     * 4: Top-left, middle, bottom-right (vertical line on right)
     * 5: Top-left, top-right, middle, bottom-left, bottom-right
     * 6: Top-left, middle, bottom-left, bottom-right (curved)
     * 7: Top-left, top-right, top-center (top heavy)
     * 8: All regions (full oval)
     * 9: Top-left, top-right, middle, bottom-right (curved top)
     */
    private static int matchRegionPatternToNumber(int[] regionCounts) {
        // Find which regions have the most bright pixels
        // Regions: [0,1,2] = top row, [3,4,5] = middle, [6,7,8] = bottom
        
        int topLeft = regionCounts[0];
        int topCenter = regionCounts[1];
        int topRight = regionCounts[2];
        int midLeft = regionCounts[3];
        int midCenter = regionCounts[4];
        int midRight = regionCounts[5];
        int botLeft = regionCounts[6];
        int botCenter = regionCounts[7];
        int botRight = regionCounts[8];
        
        // Count active regions (above average)
        int avgCount = (topLeft + topCenter + topRight + midLeft + midCenter + midRight + botLeft + botCenter + botRight) / 9;
        int threshold = avgCount / 2;
        
        int activeTop = (topLeft > threshold ? 1 : 0) + (topCenter > threshold ? 1 : 0) + (topRight > threshold ? 1 : 0);
        int activeMid = (midLeft > threshold ? 1 : 0) + (midCenter > threshold ? 1 : 0) + (midRight > threshold ? 1 : 0);
        int activeBot = (botLeft > threshold ? 1 : 0) + (botCenter > threshold ? 1 : 0) + (botRight > threshold ? 1 : 0);
        
        // Analyze patterns
        boolean topActive = activeTop >= 1;
        boolean midActive = activeMid >= 1;
        boolean botActive = activeBot >= 1;
        boolean leftActive = (topLeft > threshold || midLeft > threshold || botLeft > threshold);
        boolean rightActive = (topRight > threshold || midRight > threshold || botRight > threshold);
        boolean centerActive = (topCenter > threshold || midCenter > threshold || botCenter > threshold);
        
        // Pattern matching for digits 2-9
        
        // 2: Top, middle, bottom all active; alternates left/right
        if (topActive && midActive && botActive && (topLeft > topRight) && (botRight > botLeft)) {
            return 2;
        }
        
        // 3: Right side heavy, top and bottom active
        if (rightActive && topActive && botActive && rightActive) {
            return 3;
        }
        
        // 4: Left heavy top, vertical line on right
        if (topLeft > midLeft && rightActive) {
            return 4;
        }
        
        // 5: Similar to 2 but slightly different distribution
        if (topActive && botActive && topLeft > topRight && midLeft > midRight) {
            return 5;
        }
        
        // 6: Curved, bottom-left heavy
        if (botLeft > botRight && midLeft > midRight && topActive) {
            return 6;
        }
        
        // 7: Very top heavy, mostly top-right
        if (activeTop >= 2 && (midActive + botActive) < activeTop) {
            return 7;
        }
        
        // 8: Balanced, all regions active (oval shape)
        if (leftActive && rightActive && topActive && botActive && midActive) {
            return 8;
        }
        
        // 9: Top-right heavy, curved down
        if (topRight > topLeft && botRight > botLeft && topActive) {
            return 9;
        }
        
        return -1;
    }
    
    /**
     * Gets the last detected number
     */
    public static int getLastDetectedNumber() {
        return lastDetectedNumber;
    }
    
    /**
     * Resets detection state
     */
    public static void reset() {
        lastDetectedNumber = -1;
        ticksSinceLastDetection = 0;
        consecutiveMatches = 0;
    }
}
