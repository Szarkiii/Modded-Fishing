package com.example.moddedfishing;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafxmod.FXModLoadingContext;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(ModdedAutoFishing.MOD_ID)
public class ModdedAutoFishing {
    public static final String MOD_ID = "moddedfishing";
    private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public ModdedAutoFishing() {
        IEventBus modEventBus = FXModLoadingContext.getInstance().getModEventBus();

        // Register setup methods
        modEventBus.addListener(this::commonSetup);

        // Register config
        ModLoadingContext.getInstance().registerConfig(ModConfig.Type.COMMON, ModdedFishingConfig.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("Modded Auto Fishing addon loaded!");
        LOGGER.info("Press 'F' to toggle auto-fishing (color slot clicking)");
        LOGGER.info("The addon will automatically click the correct hotbar slot based on the color number shown");
    }
}
